# 등산로 주차장 검증 도구

GPS 좌표 기반으로 지도 이미지를 가져와 **Gemini Vision**으로 분석하여 실제 사용 가능한 주차장인지 검증하는 도구입니다.

## 🎁 무료로 사용 가능!

Gemini 무료 티어 (일 1,500회)로 **약 4~8일이면 전체 12,000개 분석 가능**합니다.

## 설치

### 1. Conda 설치

Conda가 설치되어 있지 않은 경우:

**macOS (Homebrew 사용 시):**
```bash
brew install --cask anaconda
```

**또는 Miniconda 설치:**
```bash
# macOS/Linux
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-MacOSX-x86_64.sh
bash Miniconda3-latest-MacOSX-x86_64.sh

# 또는 공식 사이트에서 다운로드
# https://docs.conda.io/en/latest/miniconda.html
```

**Windows:**
- https://docs.conda.io/en/latest/miniconda.html 에서 설치 파일 다운로드 후 실행

### 2. Conda 환경 생성 및 활성화

```bash
# Python 3.10 환경 생성
conda create -n parking python=3.10 -y

# 환경 활성화
conda activate parking

# Windows의 경우
# conda activate parking
```

### 3. 패키지 설치

```bash
pip install -r requirements.txt
```

## 환경 설정

프로젝트 루트에 `.env` 파일을 생성하고 다음 API 키를 설정하세요:

```env
# Gemini API Key (필수)
GEMINI_API_KEY=your-gemini-api-key-here

# Google Static Maps API Key (선택 - 권장)
# 위성 이미지를 가져오기 위해 사용
GOOGLE_MAPS_API_KEY=your-google-maps-api-key-here

# Kakao Maps API Key (선택 - Google 없을 시 대체)
KAKAO_API_KEY=your-kakao-api-key-here
```

## 사용법

### 비용 예측

```bash
python validate_parking.py --estimate-cost
```

### 전체 주차장 검증

```bash
# 기본 실행 (사전 필터링 + Gemini 이미지 분석)
python validate_parking.py

# 출력 파일 지정
python validate_parking.py --output 검증결과.csv

# 샘플 테스트 (처음 10개만)
python validate_parking.py --sample 10

# 최저 비용: 텍스트만 분석 (이미지 없음)
python validate_parking.py --text-only

# 이미지 저장과 함께 검증
python validate_parking.py --save-images
```

### 단일 주차장 테스트

```bash
# CSV 첫 번째 항목으로 테스트
python validate_parking.py --test

# 특정 좌표로 테스트
python validate_parking.py --test --lat 37.5665 --lng 126.978 --name "테스트 주차장"
```

## 출력 결과

검증 완료 후 CSV 파일에 다음 칼럼이 추가됩니다:

| 칼럼명 | 설명 |
|--------|------|
| `is_available` | T(사용가능) / F(사용불가) / U(판단불가) |
| `validation_confidence` | 확신도 (high/medium/low) |
| `validation_reason` | 판단 근거 설명 |
| `filter_method` | 분석 방법 (text_prefilter / gemini 등) |

## 판단 기준

### 사용 불가능 (False)으로 판단되는 경우
- 식당, 카페, 음식점 전용 주차장
- 교회, 종교시설 전용 주차장
- 사기업, 회사 전용 주차장
- 아파트, 주거시설 전용 주차장
- 병원, 의원 전용 주차장
- 특정 상업시설 고객 전용 주차장

### 사용 가능 (True)으로 판단되는 경우
- 공영주차장, 공공주차장
- 국립공원, 자연휴양림 주차장
- 관광지, 명승지 주차장
- 유료/무료 공공 주차장
- 등산객을 위한 공용 주차장

## 💰 비용

| 항목 | 비용 |
|------|------|
| **Gemini Flash** | **무료** (일 1,500회) |
| Google Static Maps | 무료 (월 $200 크레딧) |
| Kakao Maps | 무료 |

### 예상 소요 시간

텍스트 사전 필터링으로 약 60% 자동 분류 → 이미지 분석 약 5,000건

- **무료 티어**: 5,000 ÷ 1,500 = **약 4일**
- 레이트 리밋: 분당 15회 → 시간당 900회

## 주의사항

1. Gemini 무료 티어는 **분당 15회** 제한이 있어 자동으로 딜레이가 적용됩니다
2. 이미지 품질에 따라 분석 정확도가 달라질 수 있습니다
3. 판단이 어려운 경우 'U'(Unknown)로 표시되며 수동 확인이 필요합니다

